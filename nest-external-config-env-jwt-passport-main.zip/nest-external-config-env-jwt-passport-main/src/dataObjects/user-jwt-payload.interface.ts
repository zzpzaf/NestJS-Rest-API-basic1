export interface UserJwtPayload {
  username: string;
  typeid: number;
}
