# nest-external-config-env-jwt-passport

### [Nest](https://github.com/nestjs/nest) REST API - @nestjs/jwt, passport, @nestjs/passport, and passport-jwt

-------


This repo is the clean next step of the [nest-external-config-env-jwt](https://github.com/zzpzaf/nest-external-config-env-jwt.git). passport, @nestjs/passport, and passport-jwt packages have been added and the example code has been implemented. You can use it also as a base to proceed to add Passport and JWT-Strategy support for your NestJS REST API Project.


### Clone this Repo

Use the url of this repo: https://github.com/zzpzaf/nest-external-config-env-jwt-passport.git to clone it. e.g.,

`git clone https://github.com/zzpzaf/nest-external-config-env-jwt-passport.git`

### License
[MIT](https://choosealicense.com/licenses/mit/)

